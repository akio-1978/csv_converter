# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['j2render', 'j2render.command', 'j2render.render']

package_data = \
{'': ['*']}

install_requires = \
['Jinja2>=3.0.1,<4.0.0']

entry_points = \
{'console_scripts': ['j2render = j2render.starter:main']}

setup_kwargs = {
    'name': 'j2render',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'akio-1978',
    'author_email': 'akio.ogawa01@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
